import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  CheckCircle2,
  Workflow,
  Bot,
  PhoneCall,
  Database,
  Rocket,
  ArrowRight,
  Mail,
  Clock,
  ShieldCheck,
  Link as LinkIcon,
  CreditCard,
  Send,
} from "lucide-react";

/**
 * ============================
 *  CONFIG — EDIT THESE LATER
 * ============================
 * 1) WEBHOOK_URL: Replace with your Make.com or Pipedream endpoint
 * 2) SIMULATION_MODE: Set to false once you have a live webhook
 * 3) FIELD KEYS: If you change field names, update buildPayload()
 */
const WEBHOOK_URL = "https://example.com/webhook/demo"; // TODO: Replace with your Make.com/Pipedream URL
const SIMULATION_MODE = true; // TODO: Set to false when using a real webhook

/** Example payload (for reference only)
 * We send minimal PII. Adjust to your schema as needed.
 */
const DEMO_PAYLOAD_EXAMPLE = {
  source: "website-demo",
  submitted_at: new Date().toISOString(),
  contact: {
    name: "Ada Lovelace",
    email: "ada@example.com",
  },
  intent: {
    first_automation: "I want calls and web forms to create jobs automatically.",
  },
  metadata: {
    page: "/#contact",
    utm: {},
  },
};

// Brand: SmallBiz AI Works — smallbizaiworks.com (suggested)
// Palette: blues, light gray, white. Boutique capacity; gear-cluster model.

export default function Site() {
  const sections = [
    { id: "home", label: "Home" },
    { id: "about", label: "About" },
    { id: "services", label: "Services" },
    { id: "workflow", label: "Workflow" },
    { id: "process", label: "Process" },
    { id: "case-studies", label: "Case Studies" },
    { id: "playbooks", label: "Playbooks" },
    { id: "tooling", label: "Tooling" },
    { id: "contact", label: "Demo" },
  ];

  useEffect(() => {
    const id = window.location.hash?.replace('#','');
    if (id) document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  return (
    <div className="min-h-screen text-slate-800 bg-gradient-to-b from-white via-slate-50 to-slate-100">
      <Header sections={sections} onNav={scrollTo} />
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Hero onCta={() => scrollTo('contact')} />
        <About />
        <Services />
        <WorkflowSection />
        <Process />
        <CaseStudies />
        <Playbooks />
        <Tooling />
        <Results />
        <FAQ />
        <Contact />
      </main>
      <Footer onNav={scrollTo} sections={sections} />
    </div>
  );
}

function Header({ sections, onNav }) {
  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-white/80 border-b border-slate-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 shadow-md" />
          <div className="font-semibold text-slate-900">SmallBiz AI Works</div>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          {sections.map((s) => (
            <button key={s.id} onClick={() => onNav(s.id)} className="text-sm text-slate-600 hover:text-slate-900">
              {s.label}
            </button>
          ))}
          <Button onClick={() => onNav('contact')} className="rounded-2xl">Try the Demo</Button>
        </nav>
      </div>
    </header>
  );
}

function Hero({ onCta }) {
  return (
    <section id="home" className="py-16 sm:py-24">
      <div className="grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-3xl sm:text-5xl font-extrabold text-slate-900 leading-tight">
            Automation & AI that frees small teams to do real work
          </motion.h1>
          <p className="mt-4 text-slate-600 text-lg">
            40+ years building business systems. We work with one or two clients at a time so your project gets near‑exclusive attention.
          </p>
          <div className="mt-6 flex gap-3">
            <Button size="lg" onClick={onCta} className="rounded-2xl">Submit the demo form</Button>
            <Button size="lg" variant="secondary" onClick={() => document.getElementById('workflow')?.scrollIntoView({behavior:'smooth'})} className="rounded-2xl">
              See the gears turn <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <p className="mt-3 text-sm text-slate-500 flex items-center gap-2"><ShieldCheck className="h-4 w-4"/> No fluff. Clear scope, measurable results, weekly demos.</p>
        </div>
        {/* Illustration: Unsplash photo with overlay gears */}
        <motion.div initial={{ opacity: 0, scale: .98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .6, delay: .1 }} className="relative">
          <HeroArt />
        </motion.div>
      </div>
    </section>
  );
}

function HeroArt() {
  return (
    <div className="aspect-[16/10] w-full rounded-2xl overflow-hidden border border-slate-200 shadow-sm relative">
      <img
        src="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?q=80&w=1600&auto=format&fit=crop"
        alt="Calm blue abstract"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-tr from-white/40 to-blue-600/20" />
      <div className="absolute inset-0 p-6 flex items-center justify-center">
        <GearCanvas />
      </div>
    </div>
  );
}

function GearCanvas() {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <svg viewBox="0 0 400 240" className="w-full h-full">
        <defs>
          <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#60a5fa"/>
            <stop offset="100%" stopColor="#1d4ed8"/>
          </linearGradient>
        </defs>
        <Gear cx={110} cy={120} r={40} teeth={10} speed={6} label="Trigger" />
        <Gear cx={200} cy={120} r={28} teeth={10} speed={-9} label="Decide" />
        <Gear cx={270} cy={90} r={22} teeth={8} speed={12} label="Act" />
        <Gear cx={300} cy={150} r={18} teeth={8} speed={-14} label="Notify" />
        <Arrow x1={60} y1={120} x2={90} y2={120} />
        <text x={40} y={124} className="fill-slate-800" style={{fontSize:12}}>Form / Call / Event</text>
      </svg>
    </div>
  );
}

function Gear({ cx, cy, r, teeth, speed, label }) {
  const teethPath = [];
  const inner = r * 0.75;
  for (let i=0; i<teeth; i++) {
    const a0 = (i/teeth) * Math.PI * 2;
    const a1 = ((i+0.5)/teeth) * Math.PI * 2;
    const a2 = ((i+1)/teeth) * Math.PI * 2;
    teethPath.push(`M ${cx + inner*Math.cos(a0)} ${cy + inner*Math.sin(a0)} L ${cx + r*Math.cos(a1)} ${cy + r*Math.sin(a1)} L ${cx + inner*Math.cos(a2)} ${cy + inner*Math.sin(a2)} Z`);
  }
  return (
    <g>
      <motion.g animate={{ rotate: 360 }} transition={{ repeat: Infinity, ease: "linear", duration: speed<0 ? -speed : speed }} style={{ originX: cx, originY: cy }}>
        {teethPath.map((d, i) => (
          <path key={i} d={d} fill="url(#g1)" opacity={0.85} />
        ))}
        <circle cx={cx} cy={cy} r={inner*0.9} fill="white" stroke="#93c5fd" />
      </motion.g>
      <text x={cx} y={cy+4} textAnchor="middle" className="fill-slate-800" style={{fontSize:12}}>{label}</text>
    </g>
  );
}

function Arrow({ x1, y1, x2, y2 }) {
  return (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#60a5fa" strokeWidth={3} />
      <polygon points={`${x2},${y2} ${x2-8},${y2-5} ${x2-8},${y2+5}`} fill="#60a5fa" />
    </g>
  );
}

function Pill({ icon: Icon, children }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full bg-blue-50 text-blue-700 px-3 py-1 text-xs border border-blue-100">
      <Icon className="h-3.5 w-3.5" /> {children}
    </div>
  );
}

function About() {
  return (
    <section id="about" className="py-16">
      <div className="grid lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Boutique, hands‑on, outcome‑driven</h2>
          <p className="mt-4 text-slate-600">
            We help small teams turn messy manual work into click‑simple flows. You’ll work directly with a senior developer who has been building systems for over four decades.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Pill icon={Clock}>One or two clients at a time</Pill>
            <Pill icon={CheckCircle2}>Weekly progress demos</Pill>
            <Pill icon={ShieldCheck}>Plain‑language docs</Pill>
          </div>
        </div>
        <Card className="rounded-2xl shadow-sm border-slate-200 overflow-hidden">
          <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1200&auto=format&fit=crop" alt="Team collaborating" className="w-full h-36 object-cover"/>
          <CardHeader>
            <CardTitle className="text-slate-900">What clients value</CardTitle>
          </CardHeader>
          <CardContent className="text-slate-600 space-y-3">
            <div className="flex gap-3"><Bot className="h-5 w-5 text-blue-600"/><span>Call and web forms that kick off entire workflows automatically.</span></div>
            <div className="flex gap-3"><Workflow className="h-5 w-5 text-blue-600"/><span>Consistency: each job follows the same smart path, end‑to‑end.</span></div>
            <div className="flex gap-3"><Database className="h-5 w-5 text-blue-600"/><span>Data you can trust for billing, reporting, and decisions.</span></div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

function Services() {
  const items = [
    { icon: PhoneCall, title: "Voice, SMS, and IVR", body: "Smart call intake, texting, and phone trees that collect the right info and start work without delay." },
    { icon: Workflow, title: "Workflow Automation", body: "Event‑driven flows where one action triggers many: updates, emails, tasks, invoices, and alerts." },
    { icon: Database, title: "Data & Systems Integration", body: "Tie forms, CRMs, accounting, and storage together so the same data moves cleanly across tools." },
    { icon: Bot, title: "AI Assistance", body: "Transcription, intent parsing, summaries, and decision support embedded in your daily work." },
  ];
  return (
    <section id="services" className="py-16">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Services</h2>
      <p className="mt-3 text-slate-600">We keep the list short so the work stays sharp.</p>
      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {items.map((s, i) => (
          <Card key={i} className="rounded-2xl border-slate-200 hover:shadow-md transition overflow-hidden">
            <img src={`https://images.unsplash.com/photo-15${i%2?"87":"03"}76166102-3a29ace6c8f8?q=80&w=1200&auto=format&fit=crop`} alt="Service illustration" className="w-full h-28 object-cover"/>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-slate-900"><s.icon className="h-5 w-5 text-blue-600"/>{s.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600">{s.body}</CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

function WorkflowSection() {
  const steps = [
    { title: "Trigger", body: "A form, call, or payment starts the flow." },
    { title: "Intake", body: "We collect clean, structured details." },
    { title: "Decide", body: "Rules & AI help route and choose next actions." },
    { title: "Act", body: "Create jobs, tasks, tickets, or invoices." },
    { title: "Notify", body: "Update staff and customers by text or email." },
    { title: "Measure", body: "Dashboards show progress and blockers." },
  ];
  return (
    <section id="workflow" className="py-16">
      <div className="flex items-baseline justify-between">
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">The Gear‑Cluster Model</h2>
        <div className="text-sm text-slate-500">One action drives many others</div>
      </div>
      <p className="mt-3 text-slate-600 max-w-3xl">Think of your business as a set of gears. When the first gear turns—say a customer fills a form—the motion transfers to the others: jobs get created, people get notified, records get updated. No extra cranking.</p>
      <div className="mt-8 grid md:grid-cols-3 gap-5">
        {steps.map((s, i) => (
          <Card key={i} className="rounded-2xl border-slate-200">
            <CardHeader>
              <CardTitle className="text-slate-900">{i+1}. {s.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600">{s.body}</CardContent>
          </Card>
        ))}
      </div>
      <div className="mt-6">
        <Button className="rounded-2xl" onClick={() => document.getElementById('process')?.scrollIntoView({behavior:'smooth'})}>See how we run projects <ArrowRight className="ml-2 h-4 w-4"/></Button>
      </div>
    </section>
  );
}

function Process() {
  const phases = [
    { title: "Discovery", body: "Map your current path. Define success in plain numbers and simple outcomes." },
    { title: "Design", body: "Sketch the gear‑cluster: inputs, rules, outputs. Quick mockups to agree on flow." },
    { title: "Build", body: "Short, weekly sprints. Working demos, not slide decks." },
    { title: "Pilot", body: "Test with real data and adjust to fit how people actually work." },
    { title: "Launch", body: "Cutover with a checklist. Support on call." },
    { title: "Iterate", body: "Tight feedback loops keep the gears smooth." },
  ];
  return (
    <section id="process" className="py-16">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Process</h2>
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {phases.map((p, i) => (
          <Card key={i} className="rounded-2xl border-slate-200 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1200&auto=format&fit=crop" alt="Process" className="w-full h-28 object-cover"/>
            <CardHeader>
              <CardTitle className="text-slate-900">{i+1}. {p.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600">{p.body}</CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

function CaseStudies() {
  const cases = [
    {
      title: "43°N 171° Storage — hands‑off rentals",
      url: "https://43n171storage.com/",
      summary: "Customer picks size and unit; Stripe confirms payment; Airtable stores record; unit is assigned and access granted instantly — no staff touch.",
      img: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92f?q=80&w=1200&auto=format&fit=crop",
      notes: ["Self‑serve selection", "Instant Stripe confirmation", "Airtable record + permissions"],
    },
    {
      title: "NEO Drain Cleaning — instant ops",
      url: "https://NEOdraincleaning.com/",
      summary: "Form submission creates customer and invoice in QuickBooks Online; all confirmations and comms are automated and fast.",
      img: "https://images.unsplash.com/photo-1581090465345-8f5260c972e9?q=80&w=1200&auto=format&fit=crop",
      link2: { label: "Job Form", url: "https://form.jotform.com/neodraincleaning/job" },
      notes: ["Auto customer + invoice (QBO)", "Email/SMS confirmations", "Zero manual entry"],
    },
  ];
  return (
    <section id="case-studies" className="py-16">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Case Studies</h2>
      <p className="mt-3 text-slate-600">Real examples of one action spinning many gears.</p>
      <div className="mt-8 grid md:grid-cols-2 gap-6">
        {cases.map((c, i) => (
          <Card key={i} className="rounded-2xl border-slate-200 overflow-hidden">
            <img src={c.img} alt={c.title} className="w-full h-40 object-cover"/>
            <CardHeader>
              <CardTitle className="text-slate-900">{c.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 space-y-3">
              <p>{c.summary}</p>
              <ul className="text-sm list-disc ml-5 space-y-1">
                {c.notes.map((n, idx) => <li key={idx}>{n}</li>)}
              </ul>
              <div className="flex flex-wrap gap-3 pt-2">
                <a className="inline-flex items-center gap-2 text-blue-700 hover:underline" href={c.url} target="_blank" rel="noreferrer"><LinkIcon className="h-4 w-4"/> Visit site</a>
                {c.link2 && (
                  <a className="inline-flex items-center gap-2 text-blue-700 hover:underline" href={c.link2.url} target="_blank" rel="noreferrer"><LinkIcon className="h-4 w-4"/> {c.link2.label}</a>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

function Playbooks() {
  const plays = [
    { title: "Quote → Invoice → Payment", lines: ["Capture details once", "Create QBO customer + invoice", "Send pay link", "Post payment to ledger"] },
    { title: "Call Intake → Job Ticket", lines: ["Capture caller intent", "Validate address", "Create job in Airtable", "Notify crew via SMS"] },
    { title: "Form → Storage Access", lines: ["Check availability", "Assign unit", "Confirm payment", "Send access instructions"] },
  ];
  return (
    <section id="playbooks" className="py-16">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Playbooks</h2>
      <p className="mt-3 text-slate-600">Reusable patterns that keep work moving without busywork.</p>
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {plays.map((p, i) => (
          <Card key={i} className="rounded-2xl border-slate-200">
            <CardHeader>
              <CardTitle className="text-slate-900">{p.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600">
              <ul className="list-disc ml-5 space-y-1 text-sm">
                {p.lines.map((l, idx) => <li key={idx}>{l}</li>)}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

function Tooling() {
  const tools = [
    { name: "Make.com", desc: "Event‑driven automation and clean visual flows." },
    { name: "Pipedream", desc: "Code‑friendly connectors and webhooks." },
    { name: "Twilio", desc: "Voice, SMS, and IVR with real‑time AI." },
    { name: "Airtable", desc: "Fast, flexible data tables and views." },
    { name: "OpenAI", desc: "Transcription, summarization, and intent parsing." },
    { name: "QuickBooks", desc: "Accurate invoicing and reconciliation hooks." },
  ];
  return (
    <section id="tooling" className="py-16">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Tools we use</h2>
      <p className="mt-3 text-slate-600">We pick the simplest stack that gets the job done.</p>
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {tools.map((t, i) => (
          <Card key={i} className="rounded-2xl border-slate-200 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1518779578993-ec3579fee39f?q=80&w=1200&auto=format&fit=crop" alt="Tools" className="w-full h-28 object-cover"/>
            <CardHeader>
              <CardTitle className="text-slate-900">{t.name}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600">{t.desc}</CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

function Results() {
  const bullets = [
    "Shorten handoffs and reduce double entry.",
    "Give customers fast, clear updates.",
    "Make billing and reporting easier.",
  ];
  return (
    <section id="results" className="py-16">
      <div className="grid lg:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">What tends to happen</h2>
          <ul className="mt-4 space-y-2 text-slate-700">
            {bullets.map((b, i) => (
              <li key={i} className="flex gap-3 items-start"><CheckCircle2 className="h-5 w-5 text-blue-600 mt-0.5"/> {b}</li>
            ))}
          </ul>
          <div className="mt-6 flex gap-3">
            <Button className="rounded-2xl" onClick={() => document.getElementById('contact')?.scrollIntoView({behavior:'smooth'})}><Rocket className="h-4 w-4 mr-2"/>Try the live demo</Button>
            <Button variant="secondary" className="rounded-2xl" onClick={() => document.getElementById('case-studies')?.scrollIntoView({behavior:'smooth'})}>See case studies</Button>
          </div>
        </div>
        <Card className="rounded-2xl border-slate-200 overflow-hidden">
          <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1200&auto=format&fit=crop" alt="Results" className="w-full h-36 object-cover"/>
          <CardHeader>
            <CardTitle className="text-slate-900">Client notes (anonymized)</CardTitle>
          </CardHeader>
          <CardContent className="text-slate-600 space-y-3">
            <p>“We finally trust our job data. The team isn’t re‑typing everything.”</p>
            <p>“The phone bot books the right jobs and sends clean info upstream.”</p>
            <p>“Our weekly meeting moved from blame to numbers.”</p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

function FAQ() {
  const qas = [
    { q: "How many clients do you work with?", a: "One or two at a time. That focus is the point." },
    { q: "How do projects start?", a: "We map the current process, pick a small win, and ship that first." },
    { q: "Do you build websites?", a: "Yes, but the website is the front door. The real work is the workflow behind it." },
    { q: "How do we communicate?", a: "Weekly demos and a shared task board. Plain language updates." },
  ];
  return (
    <section id="faq" className="py-16">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">FAQ</h2>
      <div className="mt-6 grid sm:grid-cols-2 gap-5">
        {qas.map((qa, i) => (
          <Card key={i} className="rounded-2xl border-slate-200">
            <CardHeader>
              <CardTitle className="text-slate-900">{qa.q}</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600">{qa.a}</CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [steps, setSteps] = useState([]);
  const [error, setError] = useState(null);

  const demoSteps = [
    { icon: Send, text: "Confirmation email/SMS queued", key: "notify" },
    { icon: Database, text: "Record created in Airtable", key: "db" },
    { icon: Workflow, text: "Task created on the team board", key: "task" },
    { icon: CreditCard, text: "(Optional) Payment link generated", key: "pay" },
    { icon: Bot, text: "AI summary drafted for the team", key: "ai" },
  ];

  function buildPayload() {
    // EDIT FIELD NAMES HERE if your webhook expects different keys
    return {
      source: "website-demo",
      submitted_at: new Date().toISOString(),
      contact: { name, email },
      intent: { first_automation: message },
      metadata: { page: "/#contact" },
    };
  }

  async function simulateProgress() {
    setSteps([]);
    for (let i = 0; i < demoSteps.length; i++) {
      await new Promise((r) => setTimeout(r, 500 + i * 350));
      setSteps((prev) => [...prev, { ...demoSteps[i], status: "done" }]);
    }
  }

  async function postToWebhook(payload) {
    // Functional prototype: try POST; if it fails (because placeholder), fall back to simulate
    try {
      const res = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json().catch(() => ({}));
      // If your webhook returns step info, map it here; otherwise simulate
      if (Array.isArray(data?.steps)) {
        setSteps(data.steps.map((s) => ({ text: s.label || s.text, status: s.status || "done", icon: Send })));
      } else {
        await simulateProgress();
      }
    } catch (err) {
      await simulateProgress();
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const payload = buildPayload();
    if (SIMULATION_MODE || /example\.com/.test(WEBHOOK_URL)) {
      await simulateProgress();
    } else {
      await postToWebhook(payload);
    }
    setLoading(false);
  };

  return (
    <section id="contact" className="py-16">
      <div className="grid lg:grid-cols-2 gap-8 items-start">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Live demo: one action → many results</h2>
          <p className="mt-3 text-slate-600">Fill this form to see the gears turn. In production, this wires to Make.com or Pipedream and runs the real flow.</p>
          <div className="mt-4 text-sm text-slate-500 flex items-center gap-2"><Mail className="h-4 w-4"/> brian@mickley.net</div>
        </div>
        <Card className="rounded-2xl border-slate-200">
          <CardHeader>
            <CardTitle className="text-slate-900">Try it</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-3">
              <Input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} required />
              <Input placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              <Textarea placeholder="What would you automate first?" rows={4} value={message} onChange={(e) => setMessage(e.target.value)} required />
              <div className="flex items-center justify-between">
                <div className="text-xs text-slate-500">We’ll reply in one business day.</div>
                <Button type="submit" className="rounded-2xl" disabled={loading}>
                  {loading ? "Running demo…" : "Submit & Trigger Demo"}
                </Button>
              </div>
            </form>

            {/* Demo timeline results */}
            {steps.length > 0 && (
              <div className="mt-6">
                <h4 className="font-semibold text-slate-900 mb-2">Demo actions executed:</h4>
                <ul className="space-y-2 text-slate-700">
                  {steps.map((a, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <a.icon className="h-4 w-4 text-blue-600 mt-0.5"/>
                      <span>{a.text}</span>
                      {a.status === "done" && <CheckCircle2 className="h-4 w-4 text-blue-600 ml-2 mt-0.5"/>}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Developer note section (visible only to devs if you gate by env) */}
            <div className="mt-6 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
              <div className="font-semibold mb-1">Developer notes</div>
              <ul className="list-disc ml-5 space-y-1">
                <li><b>WEBHOOK_URL</b>: {WEBHOOK_URL} (edit at top of file)</li>
                <li><b>SIMULATION_MODE</b>: {String(SIMULATION_MODE)} — set to <code>false</code> for live webhook</li>
                <li><b>Payload</b>: see <code>buildPayload()</code> and <code>DEMO_PAYLOAD_EXAMPLE</code> at top</li>
              </ul>
            </div>

          </CardContent>
        </Card>
      </div>
    </section>
  );
}

function Footer({ sections, onNav }) {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white/60">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm text-slate-600">© {new Date().getFullYear()} SmallBiz AI Works</div>
        <div className="flex flex-wrap gap-4">
          {sections.map(s => (
            <button key={s.id} onClick={() => onNav(s.id)} className="text-sm text-slate-600 hover:text-slate-900">{s.label}</button>
          ))}
        </div>
      </div>
    </footer>
  );
}
